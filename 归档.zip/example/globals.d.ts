declare module '*.css';
declare module '*.png';
declare module '*.svg';
declare module '*.scss';
declare module '*.less';
